export type UserRole = 'patient' | 'doctor' | 'admin';
export type AppointmentType = 'in-person' | 'online';
export type AppointmentStatus = 'pending' | 'approved' | 'declined' | 'completed' | 'cancelled';
export type DoctorStatus = 'pending' | 'approved' | 'rejected';

export interface User {
  _id: string;
  email: string;
  password: string;
  role: UserRole;
  createdAt: string;
}

export interface Patient {
  _id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone?: string;
  role: "patient";

  // Medical / Profile Fields
  gender?: "male" | "female" | "other";
  dateOfBirth?: string;
  province?: string;
  city?: string;
  bloodType?: string;

  allergies?: string[];
  chronicConditions?: string[];
  currentMedications?: string[];
  pastProcedures?: string[];

  emergencyContactName?: string;
  emergencyContactPhone?: string;
}


export interface Doctor extends User {
  role: 'doctor';
  firstName: string;
  lastName: string;
  specialty: string;
  province: string;
  city: string;
  registrationNumber: string;
  yearsOfExperience: number;
  clinicName: string;
  phone?: string;
  status: DoctorStatus;
}

export interface Appointment {
  _id: string;
  patientId: string;
  doctorId: string;
  type: AppointmentType;
  date: string;
  time: string;
  reason: string;
  status: AppointmentStatus;
  videoCallLink?: string;
}

export interface Medication {
  name: string;
  dosage: string;
  instructions: string;
  duration: string;
  frequency?: string;
}

export interface Prescription {
  _id: string;
  appointmentId: string;
  patientId: string;
  doctorId: string;
  medications: Medication[];
  notes?: string;
  issuedAt: string;
}
