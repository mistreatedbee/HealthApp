import { useEffect, useState, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { CalendarIcon, ClockIcon, VideoIcon, CheckIcon, XIcon } from "lucide-react";
import { useAuth } from "../../context/AuthContext";
import { appointmentAPI, patientAPI } from "../../services/api";
import { Appointment, Patient, Doctor } from "../../types";
import { Card } from "../../components/ui/Card";
import { Badge } from "../../components/ui/Badge";
import { Button } from "../../components/ui/Button";

export function DoctorDashboard() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const doctor = user as Doctor | null;

  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [patients, setPatients] = useState<Record<string, Patient>>({});
  const [loading, setLoading] = useState(true);
  const [expandedPatient, setExpandedPatient] = useState<string | null>(null);

  const loadAppointments = useCallback(async () => {
    if (!doctor?._id) return;

    try {
      const list = await appointmentAPI.getByDoctor(doctor._id);
      const sorted = list.sort(
        (a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()
      );
      setAppointments(sorted);

      const patientMap: Record<string, Patient> = {};
      for (const appt of sorted) {
        const patientId =
          typeof appt.patientId === "string"
            ? appt.patientId
            : (appt.patientId as any)?._id || String(appt.patientId);

        if (!patientId || patientMap[patientId]) continue;

        try {
          const p = await patientAPI.getById(patientId);
          patientMap[patientId] = p;
        } catch {
          console.warn("⚠️ Could not load patient:", patientId);
        }
      }
      setPatients(patientMap);
    } catch (err) {
      console.error("⚠️ Error loading doctor appointments:", err);
    }

    setLoading(false);
  }, [doctor]);

  useEffect(() => {
    if (doctor?.status === "approved") {
      loadAppointments();
    }
  }, [doctor, loadAppointments]);

  const handleApprove = async (id?: string, type?: "in-person" | "online") => {
    if (!id) return;
    await appointmentAPI.updateStatus(id, "approved");
    if (type === "online") await appointmentAPI.generateVideoLink(id);
    loadAppointments();
  };

  const handleDecline = async (id?: string) => {
    if (!id) return;
    if (confirm("Are you sure you want to decline this appointment?")) {
      await appointmentAPI.updateStatus(id, "declined");
      loadAppointments();
    }
  };

  const handleComplete = async (id?: string) => {
    if (!id) return;
    await appointmentAPI.updateStatus(id, "completed");
    navigate(`/doctor/appointments/${id}/prescription`);
  };

  const getStatusBadge = (status: string) => {
    const variants: Record<string, "default" | "success" | "warning" | "danger"> = {
      pending: "warning",
      approved: "success",
      declined: "danger",
      completed: "default",
    };
    return <Badge variant={variants[status] || "default"}>{status}</Badge>;
  };

  if (!doctor) return <p className="text-center mt-8 text-gray-500">Loading...</p>;
  if (loading) return <p className="text-center mt-8 text-gray-500">Loading...</p>;

  if (doctor.status === "pending") {
    return (
      <Card className="p-12 text-center">
        <ClockIcon className="w-16 h-16 mx-auto mb-4 text-yellow-500" />
        <h2 className="text-2xl font-bold mb-2">Application Under Review</h2>
        <p className="text-gray-600">Your doctor profile is under review.</p>
      </Card>
    );
  }

  if (doctor.status === "rejected") {
    return (
      <Card className="p-12 text-center">
        <XIcon className="w-16 h-16 mx-auto mb-4 text-red-500" />
        <h2 className="text-2xl font-bold mb-2">Application Rejected</h2>
        <p className="text-gray-600">Please contact support.</p>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Welcome, Dr. {doctor.lastName}</h1>

      <Card className="p-6">
        <h2 className="text-lg font-semibold mb-4">Appointments</h2>

        {appointments.length === 0 ? (
          <p className="text-center text-gray-500 py-8">No appointments yet</p>
        ) : (
          <div className="space-y-4">
            {appointments.map(appt => {
              const patientId =
                typeof appt.patientId === "string"
                  ? appt.patientId
                  : (appt.patientId as any)?._id || String(appt.patientId);

              const patient = patients[patientId];

              return (
                <div key={appt._id} className="border p-4 rounded-lg">
                  <div className="flex items-center justify-between">
                    <h3 className="font-semibold">
                      {patient ? `${patient.firstName} ${patient.lastName}` : "Patient info unavailable"}
                    </h3>
                    {getStatusBadge(appt.status)}
                  </div>

                  <p className="text-sm text-gray-600">
                    {patient?.city || "Location unavailable"}
                  </p>

                  <div className="flex items-center gap-4 text-sm mt-2 text-gray-500">
                    <span className="flex items-center gap-1">
                      <CalendarIcon className="w-4 h-4" />
                      {new Date(appt.date).toLocaleDateString()}
                    </span>
                    <span className="flex items-center gap-1">
                      <ClockIcon className="w-4 h-4" />
                      {appt.time}
                    </span>
                  </div>

                  {/* Toggle Full Medical History */}
                  {patient && (
                    <button
                      className="text-blue-600 text-sm mt-2 underline"
                      onClick={() =>
                        setExpandedPatient(expandedPatient === patientId ? null : patientId)
                      }
                    >
                      {expandedPatient === patientId ? "Hide Details" : "View Full Medical History"}
                    </button>
                  )}

                  {/* Expanded Patient Details */}
                  {expandedPatient === patientId && patient && (
                    <div className="mt-4 p-4 bg-gray-50 rounded-lg text-sm space-y-2">

                      <p><strong>Gender:</strong> {patient.gender || "Not provided"}</p>
                      <p><strong>Date of Birth:</strong> {patient.dateOfBirth || "Not provided"}</p>
                      <p><strong>Blood Type:</strong> {patient.bloodType || "Not provided"}</p>
                      <p><strong>Phone:</strong> {patient.phone || "Not provided"}</p>

                      <hr className="my-2" />

                      <p><strong>Allergies:</strong> {patient.allergies?.length ? patient.allergies.join(", ") : "None"}</p>
                      <p><strong>Chronic Conditions:</strong> {patient.chronicConditions?.length ? patient.chronicConditions.join(", ") : "None"}</p>
                      <p><strong>Current Medications:</strong> {patient.currentMedications?.length ? patient.currentMedications.join(", ") : "None"}</p>
                      <p><strong>Past Procedures:</strong> {patient.pastProcedures?.length ? patient.pastProcedures.join(", ") : "None"}</p>

                      <hr className="my-2" />

                      <p><strong>Emergency Contact:</strong> {patient.emergencyContactName || "None"} ({patient.emergencyContactPhone || "Not provided"})</p>
                    </div>
                  )}

                  <div className="mt-3 flex gap-2">
                    {appt.status === "pending" && (
                      <>
                        <Button size="sm" onClick={() => handleApprove(appt._id, appt.type)}>
                          <CheckIcon className="w-4 h-4 mr-1" /> Approve
                        </Button>
                        <Button size="sm" variant="danger" onClick={() => handleDecline(appt._id)}>
                          <XIcon className="w-4 h-4 mr-1" /> Decline
                        </Button>
                      </>
                    )}

                    {appt.status === "approved" && (
                      <>
                        <Button size="sm" onClick={() => handleComplete(appt._id)}>
                          Mark Complete
                        </Button>
                        {appt.type === "online" && appt.videoCallLink && (
                          <Button size="sm" variant="secondary" onClick={() => window.open(appt.videoCallLink)}>
                            <VideoIcon className="w-4 h-4 mr-1" /> Join Call
                          </Button>
                        )}
                      </>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </Card>
    </div>
  );
}
