import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { authAPI } from '../services/api';
import { Input } from '../components/ui/Input';
import { Button } from '../components/ui/Button';
export function Register() {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    password: '',
    confirmPassword: ''
  });
  const [error, setError] = useState('');
  const navigate = useNavigate();
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (!formData.firstName || !formData.lastName || !formData.email || !formData.password) {
      setError('Please fill in all fields');
      return;
    }
    if (formData.password !== formData.confirmPassword) {
      setError('Passwords do not match');
      return;
    }
    if (formData.password.length < 6) {
      setError('Password must be at least 6 characters');
      return;
    }
    try {
      authAPI.register(formData);
      navigate('/login');
    } catch (err) {
      setError('Registration failed. Please try again.');
    }
  };
  return <div className="min-h-screen bg-gradient-to-br from-blue-50 to-blue-100 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-xl p-8 w-full max-w-md">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-blue-600">HealthApp</h1>
          <p className="text-gray-600 mt-2">Create your patient account</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {error && <div className="bg-red-50 text-red-600 p-3 rounded-lg text-sm">
              {error}
            </div>}

          <div className="grid grid-cols-2 gap-4">
            <Input label="First Name" value={formData.firstName} onChange={e => setFormData({
            ...formData,
            firstName: e.target.value
          })} placeholder="John" />
            <Input label="Last Name" value={formData.lastName} onChange={e => setFormData({
            ...formData,
            lastName: e.target.value
          })} placeholder="Doe" />
          </div>

          <Input type="email" label="Email" value={formData.email} onChange={e => setFormData({
          ...formData,
          email: e.target.value
        })} placeholder="your@email.com" />

          <Input type="password" label="Password" value={formData.password} onChange={e => setFormData({
          ...formData,
          password: e.target.value
        })} placeholder="••••••••" />

          <Input type="password" label="Confirm Password" value={formData.confirmPassword} onChange={e => setFormData({
          ...formData,
          confirmPassword: e.target.value
        })} placeholder="••••••••" />

          <Button type="submit" fullWidth>
            Create Account
          </Button>
        </form>

        <div className="mt-6 text-center">
          <p className="text-sm text-gray-600">
            Already have an account?{' '}
            <Link to="/login" className="text-blue-600 hover:underline">
              Sign in
            </Link>
          </p>
        </div>
      </div>
    </div>;
}