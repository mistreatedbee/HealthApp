import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Calendar as CalendarIcon, Clock as ClockIcon } from "lucide-react";
import { useAuth } from "../../context/AuthContext";
import { appointmentAPI, doctorAPI } from "../../services/api";
import { Appointment, Doctor } from "../../types";
import { Card } from "../../components/ui/Card";
import { Badge } from "../../components/ui/Badge";

export function PatientDashboard() {
  const { user } = useAuth();
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [doctors, setDoctors] = useState<Record<string, Doctor>>({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user?._id) return;

    async function load() {
      // ✅ Additional check to satisfy ESLint (no non-null assertion needed)
      if (!user) return;

      try {
        const res = await appointmentAPI.getByPatient(user._id) as
          Appointment[] | { appointments: Appointment[] };

        const list: Appointment[] = Array.isArray(res)
          ? res
          : res.appointments ?? [];

        const upcoming = list
          .filter(a => a.status !== "completed" && a.status !== "cancelled")
          .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

        setAppointments(upcoming);

        const doctorMap: Record<string, Doctor> = {};
        for (const a of upcoming) {
          if (!doctorMap[a.doctorId]) {
            try {
              doctorMap[a.doctorId] = await doctorAPI.getById(a.doctorId);
            } catch {
              console.warn(`⚠️ Could not load doctor: ${a.doctorId}`);
            }
          }
        }

        setDoctors(doctorMap);
      } catch (err) {
        console.error("⚠️ Failed to load appointments:", err);
      }

      setLoading(false);
    }

    load();
  }, [user]);

  if (!user || loading) {
    return <p className="text-center mt-8 text-gray-500">Loading...</p>;
  }

  const getStatusBadge = (status: string) => {
    const variants: Record<string, "default" | "success" | "warning" | "danger"> = {
      pending: "warning",
      scheduled: "warning",
      approved: "success",
      declined: "danger",
      cancelled: "danger",
      completed: "default",
    };
    return <Badge variant={variants[status] || "default"}>{status}</Badge>;
  };

  // ✅ Fixed: Use proper type guard instead of 'as any'
  const displayName = user && "firstName" in user && typeof user.firstName === "string"
    ? user.firstName
    : "User";

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-gray-900">
        Welcome back, {displayName}!
      </h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="p-6">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-blue-50 rounded-full">
              <CalendarIcon className="w-6 h-6 text-blue-600" />
            </div>
            <div>
              <p className="text-sm text-gray-600">Upcoming</p>
              <p className="text-2xl font-bold">{appointments.length}</p>
            </div>
          </div>
        </Card>

        <Link to="/patient/doctors">
          <Card className="p-6 hover:shadow-md transition-shadow cursor-pointer">
            <p className="text-lg font-semibold">Book Appointment</p>
          </Card>
        </Link>

        <Link to="/patient/profile">
          <Card className="p-6 hover:shadow-md transition-shadow cursor-pointer">
            <p className="text-lg font-semibold">Edit Profile</p>
          </Card>
        </Link>
      </div>

      <Card className="p-6">
        <h2 className="text-lg font-semibold mb-4">Upcoming Appointments</h2>

        {appointments.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            <CalendarIcon className="w-12 h-12 mx-auto mb-3 text-gray-400" />
            <p>No appointments yet</p>
            <Link to="/patient/doctors">
              <button className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                Book Appointment
              </button>
            </Link>
          </div>
        ) : (
          <div className="space-y-4">
            {appointments.map(a => {
              const doc = doctors[a.doctorId];
              if (!doc) return null;

              return (
                <div key={a._id} className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-1">
                      <h3 className="font-semibold">
                        Dr. {doc.firstName} {doc.lastName}
                      </h3>
                      {getStatusBadge(a.status)}
                    </div>

                    <p className="text-sm text-gray-600">{doc.specialty}</p>

                    <div className="flex items-center gap-4 mt-2 text-sm text-gray-500">
                      <span className="flex items-center gap-1">
                        <CalendarIcon className="w-4 h-4" />
                        {new Date(a.date).toLocaleDateString()}
                      </span>
                      {a.time && (
                        <span className="flex items-center gap-1">
                          <ClockIcon className="w-4 h-4" />
                          {a.time}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </Card>
    </div>
  );
}
