import React, { useEffect, useState } from "react";
import { CalendarIcon, ClockIcon, VideoIcon } from "lucide-react";
import { appointmentAPI, doctorAPI, patientAPI } from "../../services/api";
import { Appointment, Doctor, Patient } from "../../types";
import { Card } from "../../components/ui/Card";
import { Badge } from "../../components/ui/Badge";

export function ManageAppointments() {
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [doctors, setDoctors] = useState<Record<string, Doctor>>({});
  const [patients, setPatients] = useState<Record<string, Patient>>({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadData() {
      try {
        const res = await appointmentAPI.getAll() as
          Appointment[] | { appointments: Appointment[] };

        const appts: Appointment[] = Array.isArray(res)
          ? res
          : res.appointments ?? [];

        setAppointments(
          appts.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
        );

        // Load Doctor Data
        const doctorMap: Record<string, Doctor> = {};
        const doctorIds = [...new Set(appts.map(a => a.doctorId))];
        for (const id of doctorIds) {
          try {
            doctorMap[id] = await doctorAPI.getById(id);
          } catch (err) {
            console.warn("Failed to load doctor:", id);
          }
        }
        setDoctors(doctorMap);

        // Load Patient Data
        const patientMap: Record<string, Patient> = {};
        const patientIds = [...new Set(appts.map(a => a.patientId))];
        for (const id of patientIds) {
          try {
            patientMap[id] = await patientAPI.getById(id);
          } catch (err) {
            console.warn("Failed to load patient:", id);
          }
        }
        setPatients(patientMap);

      } catch (err) {
        console.error("Failed to load appointments:", err);
      }

      setLoading(false);
    }

    loadData();
  }, []);

  if (loading) return <p className="mt-8 text-center text-gray-500">Loading appointments...</p>;

  const getStatusBadge = (status: string) => {
    const variants: Record<string, "default" | "success" | "warning" | "danger"> = {
      pending: "warning",
      approved: "success",
      declined: "danger",
      completed: "default",
      cancelled: "default",
    };
    return <Badge variant={variants[status] || "default"}>{status}</Badge>;
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Manage Appointments</h1>
        <p className="text-gray-600 mt-1">View all scheduled patient appointments</p>
      </div>

      <Card className="p-6">
        <div className="space-y-4">
          {appointments.map(appointment => {
            const doctor = doctors[appointment.doctorId];
            const patient = patients[appointment.patientId];
            return (
              <div key={appointment._id} className="border border-gray-200 rounded-lg p-4">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <h3 className="font-semibold flex items-center gap-2">
                      {patient?.firstName} {patient?.lastName} → Dr. {doctor?.firstName} {doctor?.lastName}
                    </h3>
                    <p className="text-sm text-gray-600">{doctor?.specialty}</p>
                  </div>

                  <div className="flex items-center gap-2">
                    {getStatusBadge(appointment.status)}
                    {appointment.type === "online" && (
                      <Badge variant="info">
                        <VideoIcon className="w-3 h-3 inline mr-1" /> Online
                      </Badge>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-sm text-gray-600 mt-2">
                  <div className="flex items-center gap-2">
                    <CalendarIcon className="w-4 h-4" />
                    {new Date(appointment.date).toLocaleDateString()}
                  </div>

                  <div className="flex items-center gap-2">
                    <ClockIcon className="w-4 h-4" />
                    {appointment.time}
                  </div>

                  <div>
                    {doctor?.city}, {doctor?.province}
                  </div>
                </div>

                <div className="mt-3 bg-gray-50 p-3 rounded-lg text-sm text-gray-700">
                  <span className="font-medium">Reason:</span> {appointment.reason}
                </div>
              </div>
            );
          })}
        </div>
      </Card>
    </div>
  );
}
