import React, { useEffect, useState } from "react";
import {
  UsersIcon,
  UserCheckIcon,
  CalendarIcon,
  VideoIcon,
  ClipboardIcon,
} from "lucide-react";
import { adminAPI } from "../../services/api";
import { StatCard } from "../../components/ui/StatCard";

export function AdminDashboard() {
  const [stats, setStats] = useState({
    totalPatients: 0,
    totalDoctors: 0,
    totalAppointments: 0,
    onlineAppointments: 0,
    inPersonAppointments: 0,
  });

  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadStats = async () => {
      try {
        const data = await adminAPI.getStats(); // ✅ Make sure this calls backend
        setStats(data);
      } catch (error) {
        console.error("Failed to load admin stats:", error);
      }
      setLoading(false);
    };

    loadStats();
  }, []);

  if (loading) {
    return (
      <p className="text-center mt-8 text-gray-500 text-lg">
        Loading dashboard...
      </p>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Admin Dashboard</h1>
        <p className="text-gray-600 mt-1">
          Monitor platform activity and system statistics
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <StatCard
          title="Total Patients"
          value={stats.totalPatients}
          icon={<UsersIcon className="w-6 h-6" />}
        />

        <StatCard
          title="Active Doctors"
          value={stats.totalDoctors}
          icon={<UserCheckIcon className="w-6 h-6" />}
        />

        <StatCard
          title="Total Appointments"
          value={stats.totalAppointments}
          icon={<CalendarIcon className="w-6 h-6" />}
        />

        <StatCard
          title="Online Consultations"
          value={stats.onlineAppointments}
          icon={<VideoIcon className="w-6 h-6" />}
        />

        <StatCard
          title="In-Person Visits"
          value={stats.inPersonAppointments}
          icon={<ClipboardIcon className="w-6 h-6" />}
        />
      </div>
    </div>
  );
}
