import React, { useEffect, useState } from 'react';
import { CheckIcon, XIcon } from 'lucide-react';
import { doctorAPI } from '../../services/api';
import { Doctor } from '../../types';
import { Card } from '../../components/ui/Card';
import { Badge } from '../../components/ui/Badge';
import { Button } from '../../components/ui/Button';

export function ManageDoctors() {
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadDoctors();
  }, []);

  const loadDoctors = async () => {
    try {
      setLoading(true);
      const allDoctors = await doctorAPI.getAll();
      setDoctors(allDoctors);
    } catch (err) {
      console.log("Failed to load doctors:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleApprove = async (doctorId: string) => {
    await doctorAPI.updateStatus(doctorId, "approved");
    loadDoctors();
  };

  const handleReject = async (doctorId: string) => {
    if (confirm("Are you sure you want to reject this doctor application?")) {
      await doctorAPI.updateStatus(doctorId, "rejected");
      loadDoctors();
    }
  };

  const getStatusBadge = (status: string) => {
    const variants: Record<string, 'default' | 'success' | 'warning' | 'danger'> = {
      pending: 'warning',
      approved: 'success',
      rejected: 'danger'
    };
    return <Badge variant={variants[status]}>{status}</Badge>;
  };

  if (loading) return <p className="text-center mt-8 text-gray-500">Loading...</p>;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Manage Doctors</h1>
        <p className="text-gray-600 mt-1">Review and approve doctor applications</p>
      </div>

      <Card className="p-6">
        <div className="space-y-4">
          {doctors.map(doctor => (
            <div key={doctor._id} className="border border-gray-200 rounded-lg p-4">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <div className="flex items-center gap-3 mb-2">
                    <h3 className="text-lg font-semibold">
                      Dr. {doctor.firstName} {doctor.lastName}
                    </h3>
                    {getStatusBadge(doctor.status)}
                  </div>
                  <p className="text-blue-600 font-medium">{doctor.specialty}</p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                
                <div>
                  <h4 className="text-sm font-medium text-gray-700 mb-2">Contact</h4>
                  <p className="text-sm text-gray-600">Email: {doctor.email}</p>
                  {doctor.phone && <p className="text-sm text-gray-600">Phone: {doctor.phone}</p>}
                </div>

                <div>
                  <h4 className="text-sm font-medium text-gray-700 mb-2">Practice Details</h4>
                  <p className="text-sm text-gray-600">{doctor.city}, {doctor.province}</p>
                  <p className="text-sm text-gray-600">Clinic: {doctor.clinicName}</p>
                  <p className="text-sm text-gray-600">Experience: {doctor.yearsOfExperience} years</p>
                </div>

                <div>
                  <h4 className="text-sm font-medium text-gray-700 mb-2">Credentials</h4>
                  <p className="text-sm text-gray-600">Registration #: {doctor.registrationNumber}</p>
                </div>

                <div>
                  <h4 className="text-sm font-medium text-gray-700 mb-2">Application Date</h4>
                  <p className="text-sm text-gray-600">{new Date(doctor.createdAt).toLocaleDateString()}</p>
                </div>

              </div>

              {doctor.status === "pending" && (
                <div className="flex gap-2">
                  <Button variant="primary" size="sm" onClick={() => handleApprove(doctor._id)}>
                    <CheckIcon className="w-4 h-4 mr-1" /> Approve
                  </Button>
                  <Button variant="danger" size="sm" onClick={() => handleReject(doctor._id)}>
                    <XIcon className="w-4 h-4 mr-1" /> Reject
                  </Button>
                </div>
              )}

            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
