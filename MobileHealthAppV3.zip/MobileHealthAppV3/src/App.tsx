import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Login } from './pages/Login';
import { Register } from './pages/Register';
import { DoctorRegister } from './pages/doctor/DoctorRegister';
// Patient Pages
import { PatientLayout } from './components/layout/PatientLayout';
import { PatientDashboard } from './pages/patient/PatientDashboard';
import { PatientProfile } from './pages/patient/PatientProfile';
import { DoctorList } from './pages/patient/DoctorList';
import { BookAppointment } from './pages/patient/BookAppointment';
import { PatientAppointments } from './pages/patient/PatientAppointments';
import { PatientPrescriptions } from './pages/patient/PatientPrescriptions';
// Doctor Pages
import { DoctorLayout } from './components/layout/DoctorLayout';
import { DoctorDashboard } from './pages/doctor/DoctorDashboard';
import { AppointmentDetail } from './pages/doctor/AppointmentDetail';
import { IssuePrescription } from './pages/doctor/IssuePrescription';
// Admin Pages
import { AdminLayout } from './components/layout/AdminLayout';
import { AdminDashboard } from './pages/admin/AdminDashboard';
import { ManagePatients } from './pages/admin/ManagePatients';
import { ManageDoctors } from './pages/admin/ManageDoctors';
import { ManageAppointments } from './pages/admin/ManageAppointments';
function ProtectedRoute({
  children,
  allowedRole
}: {
  children: React.ReactNode;
  allowedRole: string;
}) {
  const {
    user,
    isLoading
  } = useAuth();
  if (isLoading) {
    return <div className="min-h-screen flex items-center justify-center">
        Loading...
      </div>;
  }
  if (!user) {
    return <Navigate to="/login" />;
  }
  if (user.role !== allowedRole) {
    return <Navigate to="/login" />;
  }
  return <>{children}</>;
}
function AppRoutes() {
  const {
    user,
    isLoading
  } = useAuth();
  if (isLoading) {
    return <div className="min-h-screen flex items-center justify-center">
        Loading...
      </div>;
  }
  return <Routes>
      <Route path="/login" element={user ? <Navigate to={`/${user.role}/dashboard`} /> : <Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/doctor/register" element={<DoctorRegister />} />

      {/* Patient Routes */}
      <Route path="/patient/*" element={<ProtectedRoute allowedRole="patient">
            <PatientLayout>
              <Routes>
                <Route path="/dashboard" element={<PatientDashboard />} />
                <Route path="/profile" element={<PatientProfile />} />
                <Route path="/doctors" element={<DoctorList />} />
                <Route path="/book-appointment" element={<BookAppointment />} />
                <Route path="/appointments" element={<PatientAppointments />} />
                <Route path="/prescriptions" element={<PatientPrescriptions />} />
              </Routes>
            </PatientLayout>
          </ProtectedRoute>} />

      {/* Doctor Routes */}
      <Route path="/doctor/*" element={<ProtectedRoute allowedRole="doctor">
            <DoctorLayout>
              <Routes>
                <Route path="/dashboard" element={<DoctorDashboard />} />
                <Route path="/appointments" element={<DoctorDashboard />} />
                <Route path="/appointments/:id" element={<AppointmentDetail />} />
                <Route path="/appointments/:id/prescription" element={<IssuePrescription />} />
              </Routes>
            </DoctorLayout>
          </ProtectedRoute>} />

      {/* Admin Routes */}
      <Route path="/admin/*" element={<ProtectedRoute allowedRole="admin">
            <AdminLayout>
              <Routes>
                <Route path="/dashboard" element={<AdminDashboard />} />
                <Route path="/patients" element={<ManagePatients />} />
                <Route path="/doctors" element={<ManageDoctors />} />
                <Route path="/appointments" element={<ManageAppointments />} />
              </Routes>
            </AdminLayout>
          </ProtectedRoute>} />

      <Route path="/" element={<Navigate to="/login" />} />
    </Routes>;
}
export function App() {
  return <BrowserRouter>
      <AuthProvider>
        <AppRoutes />
      </AuthProvider>
    </BrowserRouter>;
}