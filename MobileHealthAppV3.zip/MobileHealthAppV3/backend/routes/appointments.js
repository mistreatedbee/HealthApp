import express from "express";
import Appointment from "../models/Appointment.js";

const router = express.Router();

/* ---------------------- CREATE APPOINTMENT ---------------------- */
router.post("/", async (req, res) => {
  try {
    // Remove _id if frontend sends it
    const { _id, ...data } = req.body;

    const appt = await Appointment.create({
      patientId: data.patientId,
      doctorId: data.doctorId,
      type: data.type,
      date: new Date(data.date),   // ✅ Convert string to Date
      time: data.time,
      reason: data.reason,
      status: data.status || "pending",
      videoCallLink: null
    });

    res.json({ success: true, appointment: appt });
  } catch (e) {
    console.log(e);
    res.status(500).json({
      success: false,
      message: "Error creating appointment",
      error: e.message,
    });
  }
});

/* ---------------------- GET ALL APPOINTMENTS ---------------------- */
router.get("/", async (req, res) => {
  const { status } = req.query;
  const filter = status ? { status } : {};

  const list = await Appointment.find(filter)
    .populate("patientId", "firstName lastName email")
    .populate("doctorId", "firstName lastName specialty")
    .sort({ createdAt: -1 });

  res.json({ success: true, appointments: list });
});

/* ---------------------- GET APPOINTMENTS BY PATIENT ---------------------- */
router.get("/patient/:id", async (req, res) => {
  const list = await Appointment.find({ patientId: req.params.id })
    .populate("doctorId", "firstName lastName specialty")
    .sort({ createdAt: -1 });

  res.json({ success: true, appointments: list });
});

/* ---------------------- GET APPOINTMENTS BY DOCTOR ---------------------- */
router.get("/doctor/:id", async (req, res) => {
  const list = await Appointment.find({ doctorId: req.params.id })
    .populate("patientId", "firstName lastName email")
    .sort({ createdAt: -1 });

  res.json({ success: true, appointments: list });
});

/* ---------------------- GET SINGLE APPOINTMENT ---------------------- */
router.get("/:id", async (req, res) => {
  const appt = await Appointment.findById(req.params.id);
  if (!appt)
    return res.status(404).json({ success: false, message: "Appointment not found" });

  res.json({ success: true, appointment: appt });
});

/* ---------------------- UPDATE APPOINTMENT ---------------------- */
router.put("/:id", async (req, res) => {
  const updated = await Appointment.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
  });
  res.json({ success: true, appointment: updated });
});

/* ---------------------- UPDATE STATUS ---------------------- */
router.put("/:id/status", async (req, res) => {
  const { status } = req.body;

  const updated = await Appointment.findByIdAndUpdate(
    req.params.id,
    { status },
    { new: true }
  );

  res.json({ success: true, appointment: updated });
});

/* ---------------------- CANCEL APPOINTMENT ---------------------- */
router.put("/:id/cancel", async (req, res) => {
  const updated = await Appointment.findByIdAndUpdate(
    req.params.id,
    { status: "cancelled" },
    { new: true }
  );
  res.json({ success: true, appointment: updated });
});

/* ---------------------- GENERATE VIDEO CALL LINK ---------------------- */
router.post("/:id/video-link", async (req, res) => {
  const link = `https://health-video.app/room/${req.params.id}`;

  const updated = await Appointment.findByIdAndUpdate(
    req.params.id,
    { videoCallLink: link },
    { new: true }
  );

  res.json({ success: true, link, appointment: updated });
});

/* ---------------------- DELETE APPOINTMENT ---------------------- */
router.delete("/:id", async (req, res) => {
  await Appointment.findByIdAndDelete(req.params.id);
  res.json({ success: true, message: "Deleted" });
});

export default router;
