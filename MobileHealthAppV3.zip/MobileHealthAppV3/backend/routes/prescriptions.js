import express from "express";
import mongoose from "mongoose";
import Prescription from "../models/Prescription.js";

const router = express.Router();

/* ---------------------- CREATE PRESCRIPTION ---------------------- */
router.post("/", async (req, res) => {
  try {
    const { appointmentId, patientId, doctorId, medications, notes } = req.body;

    const prescription = await Prescription.create({
      appointmentId,
      patientId,
      doctorId,
      medications,
      notes,
    });

    res.json({ success: true, prescription });
  } catch (err) {
    console.log("Error creating prescription:", err);
    res.status(500).json({ success: false, message: "Error creating prescription" });
  }
});

/* ---------------------- GET PRESCRIPTIONS FOR A PATIENT ---------------------- */
router.get("/patient/:patientId", async (req, res) => {
  try {
    const { patientId } = req.params;

    if (!mongoose.Types.ObjectId.isValid(patientId)) {
      return res.status(400).json({ success: false, message: "Invalid patient ID" });
    }

    const list = await Prescription.find({ patientId })
      .sort({ issuedAt: -1 });

    res.json({ success: true, prescriptions: list });
  } catch (err) {
    console.log("Error fetching patient prescriptions:", err);
    res.status(500).json({ success: false, message: "Error fetching prescriptions" });
  }
});

/* ---------------------- GET PRESCRIPTION BY APPOINTMENT ---------------------- */
router.get("/appointment/:appointmentId", async (req, res) => {
  try {
    const prescription = await Prescription.findOne({
      appointmentId: req.params.appointmentId,
    });

    res.json({ success: true, prescription });
  } catch (err) {
    res.status(500).json({ success: false, message: "Error fetching prescription" });
  }
});

/* ---------------------- DELETE PRESCRIPTION ---------------------- */
router.delete("/:id", async (req, res) => {
  await Prescription.findByIdAndDelete(req.params.id);
  res.json({ success: true, message: "Prescription deleted" });
});

export default router;
