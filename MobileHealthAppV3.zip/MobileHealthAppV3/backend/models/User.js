import mongoose from "mongoose";

const userSchema = new mongoose.Schema(
  {
    // Shared fields (doctor + patient)
    firstName: { type: String, required: true },
    lastName: { type: String, required: true },
    email: { type: String, unique: true, required: true },
    password: { type: String, required: true },

    role: { type: String, enum: ["patient", "doctor", "admin"], default: "patient" },

    // Patient fields
    dateOfBirth: { type: String },
    gender: { type: String, enum: ["male", "female", "other"] },
    province: { type: String }, // Shared with doctors
    city: { type: String }, // Shared with doctors
    bloodType: { type: String, enum: ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"] },
    allergies: [{ type: String }],
    chronicConditions: [{ type: String }],
    currentMedications: [{ type: String }],
    pastProcedures: [{ type: String }],
    emergencyContactName: { type: String },
    emergencyContactPhone: { type: String },
    phone: { type: String },
    age: { type: Number },

    // Doctor fields
    specialty: { type: String },
    clinicName: { type: String },
    yearsOfExperience: { type: Number },
    registrationNumber: { type: String },

    // Doctor approval status
    status: { type: String, enum: ["pending", "approved", "rejected"], default: "pending" }
  },
  { timestamps: true }
);

export default mongoose.model("User", userSchema);
