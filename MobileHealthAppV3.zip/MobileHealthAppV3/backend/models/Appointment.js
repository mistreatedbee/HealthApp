import mongoose from "mongoose";

const appointmentSchema = new mongoose.Schema(
  {
    patientId: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    doctorId: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },

    type: { type: String, enum: ["online", "in-person"], default: "in-person" },

    date: { type: Date, required: true },
    time: { type: String, required: true },

    status: {
      type: String,
      enum: ["pending", "approved", "declined", "completed", "no-show", "cancelled"],
      default: "pending"
    },

    videoCallLink: { type: String, default: null },

    reason: { type: String, required: true },
    notes: { type: String }
  },
  { timestamps: true }
);

export default mongoose.model("Appointment", appointmentSchema);
