import mongoose from "mongoose";

const prescriptionSchema = new mongoose.Schema(
  {
    appointmentId: { type: mongoose.Schema.Types.ObjectId, ref: "Appointment", required: true },
    patientId: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    doctorId: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    medications: [
      {
        name: { type: String, required: true },
        dosage: { type: String, required: true },
        frequency: { type: String, required: false }, // ✅ Optional
        instructions: { type: String, required: false },
        duration: { type: String, required: true }
      }
    ],
    notes: { type: String },
    issuedAt: { type: Date, default: Date.now }
  },
  { timestamps: true }
);

export default mongoose.model("Prescription", prescriptionSchema);
