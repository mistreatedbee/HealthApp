/* eslint-env node */
import express from "express";
import mongoose from "mongoose";
import cors from "cors";
import dotenv from "dotenv";

import authRoutes from "./routes/auth.js";
import userRoutes from "./routes/users.js";
import appointmentRoutes from "./routes/appointments.js";
import prescriptionRoutes from "./routes/prescriptions.js";
import doctorRoutes from "./routes/doctors.js";
import patientRoutes from "./routes/patients.js";
import adminRoutes from "./routes/admin.js";





// Load .env file
dotenv.config({ path: "./.env" });

const app = express();

// Allow requests from frontend
app.use(cors({
  origin: "http://localhost:5173",
  credentials: true
}));

// Allow JSON in requests
app.use(express.json());

// DEBUG: Check if Mongo URI is loaded
console.log("🔍 MONGO_URI Loaded:", process.env.MONGO_URI ? "YES ✅" : "NO ❌");

// Connect to MongoDB
mongoose
  .connect(process.env.MONGO_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true
  })
  .then(() => console.log("✅ MongoDB Connected Successfully"))
  .catch((error) => console.log("❌ MongoDB Connection Error:", error.message));

// Basic route test
app.get("/", (req, res) => {
  res.send("✅ Backend API is running correctly");
});

// API Routes
app.use("/auth", authRoutes);
app.use("/users", userRoutes);
app.use("/appointments", appointmentRoutes);
app.use("/prescriptions", prescriptionRoutes);
app.use("/doctors", doctorRoutes);
app.use("/patients", patientRoutes);
app.use("/admin", adminRoutes);
app.use("/prescriptions", prescriptionRoutes);
app.use("/patients", patientRoutes);


// Start Backend Server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`🚀 Server Running → http://localhost:${PORT}`));
